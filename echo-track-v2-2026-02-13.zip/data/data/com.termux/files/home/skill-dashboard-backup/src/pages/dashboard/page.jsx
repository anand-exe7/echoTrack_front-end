import React, { useState } from 'react';
import LevelCard from '../../components/dashboard/LevelCard';
import SkillCard from '../../components/dashboard/SkillCard';
import AIInsightSection from '../../components/dashboard/AIInsightSection';
import BadgesSection from '../../components/dashboard/BadgesSection';
import SkillTimeline from '../../components/dashboard/SkillTimeline';

const MOCK_DATA = {
  profile: { name: "Akshay P", regNo: "RA2511026020039" },
  xp: { total_xp: 480 },
  globalRank: { current: 360, leader: "Alex Johnson" },
  uniRank: { current: 14, leader: "Sarah Miller" },
  // Team 14 members for the leaderboard
  team: [
    { name: "Akshay P", rank: 14, xp: 1280, badges: 6 },
    { name: "Adwaith AN", rank: 18, xp: 1150, badges: 4 },
    { name: "Aazad", rank: 22, xp: 980, badges: 3 },
    { name: "Anuj", rank: 25, xp: 850, badges: 3 },
    { name: "Dhruv", rank: 30, xp: 720, badges: 2 }
  ],
  skills: [
    { skill_name: "EchoTrack Data Art", xp: 500, date_added: "2026-02-12" },
    { skill_name: "AI Skill Mentor", xp: 300, date_added: "2026-02-11" },
    { skill_name: "Frontend Dashboard", xp: 250, date_added: "2026-02-10" },
    { skill_name: "Termux Init", xp: 100, date_added: "2026-02-09" },
    { skill_name: "C-based Club App", xp: 450, date_added: "2026-02-03" },
    { skill_name: "CrisisWatch MVP", xp: 400, date_added: "2026-01-31" },
    { skill_name: "hashlo Brand Logo", xp: 200, date_added: "2025-12-21" },
    { skill_name: "JavaScript Logic", xp: 180, date_added: "2025-12-15" },
    { skill_name: "Crucial SSD Setup", xp: 120, date_added: "2025-12-04" },
    { skill_name: "Blue Dart Tracking", xp: 50, date_added: "2025-11-20" },
    { skill_name: "Malayalam News API", xp: 90, date_added: "2025-11-15" },
    { skill_name: "Advanced Mathematics", xp: 300, date_added: "2025-11-12" },
    { skill_name: "Phone Zones Order", xp: 60, date_added: "2025-11-09" },
    { skill_name: "Biryani Finder UI", xp: 40, date_added: "2025-11-04" },
    { skill_name: "HP Victus Config", xp: 110, date_added: "2025-10-19" },
    { skill_name: "Chemistry Reactor", xp: 220, date_added: "2025-10-10" },
    { skill_name: "Team 14 Init", xp: 80, date_added: "2025-09-28" },
    { skill_name: "Photography Suite", xp: 140, date_added: "2025-09-16" },
    { skill_name: "Classical Music Player", xp: 70, date_added: "2025-04-12" }
  ],
  badges: [
    { title: "First Step", icon: "🌱", earned: true, date: "Feb 01", requirement: "Upload first skill" },
    { title: "Streak Master", icon: "🔥", earned: true, date: "Feb 10", requirement: "10-day streak" },
    { title: "Data Artist", icon: "🎨", earned: true, date: "Feb 09", requirement: "Setup EchoTrack" },
    { title: "Terminal King", icon: "💻", earned: true, date: "Feb 13", requirement: "Termux init" },
    { title: "Hardware Guy", icon: "🛠️", earned: true, date: "Dec 04", requirement: "Upgrade SSD" },
    { title: "Team Player", icon: "🤝", earned: true, date: "Sep 28", requirement: "Join Team 14" }
  ]
};

export default function DashboardPage() {
  const [modal, setModal] = useState(null);

  return (
    <div className="min-h-screen bg-[#F4F5FF] p-6 space-y-12 pb-20">
      {/* Summary Header */}
      <section id="hero" className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => setModal({ type: 'Global', current: 360, leader: "Alex Johnson" })}
            className="bg-gradient-to-br from-indigo-500 to-indigo-700 p-8 rounded-3xl text-white shadow-lg relative overflow-hidden text-left hover:scale-[1.02] transition-transform"
          >
            <p className="opacity-80 text-xs font-bold uppercase tracking-widest">Global Rank</p>
            <h2 className="text-5xl font-black mt-1">#360</h2>
            <p className="mt-4 text-sm font-medium">{MOCK_DATA.profile.name} • RA2511026020039</p>
            <div className="absolute -right-4 -bottom-4 text-9xl opacity-10 font-black italic">GLOB</div>
          </button>

          <button 
            onClick={() => setModal({ type: 'University', current: 14, leader: "Sarah Miller", isTeam: true })}
            className="bg-white p-8 rounded-3xl border border-indigo-100 shadow-sm text-left relative overflow-hidden hover:scale-[1.02] transition-transform"
          >
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">University Rank</p>
            <h2 className="text-5xl font-black text-indigo-600 mt-1">#14</h2>
            <p className="mt-4 text-sm font-bold text-indigo-400 uppercase tracking-tight">Team 14 • Leading</p>
            <div className="absolute -right-4 -bottom-4 text-9xl opacity-5 font-black italic text-indigo-900">UNI</div>
          </button>
        </div>
        
        <LevelCard xp={MOCK_DATA.xp.total_xp} />
      </section>

      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SkillTimeline skills={MOCK_DATA.skills} />
        <AIInsightSection />
      </div>

      <section id="preview" className="max-w-6xl mx-auto">
        <BadgesSection badges={MOCK_DATA.badges} />
      </section>

      {/* Leaderboard Modal */}
      {modal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-indigo-900/20 backdrop-blur-md">
          <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-lg w-full border border-indigo-50 animate-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-black text-indigo-900">{modal.type} Leaderboard</h3>
              <button onClick={() => setModal(null)} className="text-slate-400 hover:text-indigo-600 font-bold">Close</button>
            </div>
            
            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest px-4 mb-2">
                <span>Rank | User</span>
                <span>XP / Badges</span>
              </div>
              
              {/* Leader Placeholder */}
              <div className="flex justify-between items-center p-4 bg-amber-50 rounded-2xl border border-amber-100 mb-4">
                <span className="font-black text-amber-600">#1 | {modal.leader}</span>
                <span className="text-xs font-bold text-amber-700">24,500 XP</span>
              </div>

              {/* Team Leaderboard Content */}
              {MOCK_DATA.team.map((user, i) => (
                <div 
                  key={i} 
                  className={`flex justify-between items-center p-4 rounded-2xl border transition-all ${
                    user.name === "Akshay P" 
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md' 
                    : 'bg-white border-indigo-50 text-slate-600 hover:border-indigo-200'
                  }`}
                >
                  <div className="flex flex-col">
                    <span className="font-black text-sm">#{user.rank} | {user.name}</span>
                    <span className={`text-[10px] uppercase font-bold ${user.name === "Akshay P" ? 'text-indigo-100' : 'text-slate-400'}`}>
                      {user.name === "Akshay P" ? "Current User" : "Team 14 Member"}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-sm">{user.xp} XP</p>
                    <p className={`text-[10px] font-bold ${user.name === "Akshay P" ? 'text-indigo-100' : 'text-slate-400'}`}>{user.badges} Badges</p>
                  </div>
                </div>
              ))}
            </div>
            
            <button 
              onClick={() => setModal(null)}
              className="mt-8 w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
